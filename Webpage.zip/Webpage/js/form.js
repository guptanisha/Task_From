function A(star)
{
	if(B(star.T1," Enter the  First Name:")== false)
	{
		star.T1.focus;
		return false;
	}
	else if( B(star.T2," Enter the Last name:")==false)
	{
	   star.T1.focus;
		return false;
	}
	else if( B(star.T3," Enter the Email:")==false)
	{
	   star.T1.focus;
		return false;
	}
	else if( B(star.T4," Enter the Company Name:")==false)
	{
	   star.T1.focus;
		return false;
	}
	else if( B(star.T5," Enter the Contact Number:")==false)
	{
	   star.T1.focus;
		return false;
	}
}
      
	
function B(star,msg)
{
if(star.value=="" || star.value=="null")
{
	alert(msg);
	return false;
	}
	else
	{
		return true;
		}
}// JavaScript Document