<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ContactUs</title>
</head>

<body background="../img/background.jpg">
      <?php
	  require_once"include/db_config.php";
       $firstname=$_REQUEST["T1"];
      $lastname=$_REQUEST["T2"];
     $email=$_REQUEST["T3"];
     $company=$_REQUEST["T4"];
     $contact=$_REQUEST["T5"];
	  
	 $sql="Insert into userdata values('$firstname','$lastname','$email','$company','$contactcn')";
     mysql_query($sql);
     $n= mysql_affected_rows();
     if ($n==0)
     {
      echo "<br> row not inserted";
      die();
     }
     
	   
      ?>
      <center>
      <p >
      <h1 style="color:#FF9; margin-top:200px;">Register Successfully</h1>
      <a href="../Form.html" style="color:#C60";">Continue</a>
      </p>
      </center>
</body>
</html>