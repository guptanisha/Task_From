<?php
$cn =mysql_connect("localhost","root","");
     if (!$cn)
     {
      echo "unable to connect";die();
     }
     $db=mysql_select_db("form_db",$cn);
     if(!$db)

     {
      echo "database does not exist"; die();

     }
	 function generateid ($startnum,$tablename)
	 {
		 global $cn;
		 $sql= "SELECT * from ".$tablename;
		 $result= mysql_query($sql,$cn);
		 $id=0;
		 while($rw=mysql_fetch_array($result))
		 {
			 $id++;
		 }
		 $id=$id+$startnum;
		 return $id;
	 }
	 
?>