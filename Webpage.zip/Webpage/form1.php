<?php
$name=$_POST["fname"]." ".$_POST["lname"];
#specify particular mail Id
$to="nisha.g1466@gmail.com"; 
$from=$_POST["email"];
$message=" Name: ".$name." <br> Phone: ".$_POST["phone"]." <br> Fax: ".$_POST["fax"]." <br> From: ".$_POST["email"].
"<br> Company:".$_POST['company'].;
$headers="MIME-Version: 1.0\r\n"; 
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";  
$headers .="From: ". $from;
$mailsent=mail($to, $subject, $message, $headers);
if ($mailsent)
 {
    header("location:Form.html?val=1");

 } 

?>